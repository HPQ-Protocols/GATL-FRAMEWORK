import time
from shamir.split import split_secret
from shamir.combine import combine_shares
from network.multipath import NetworkEnvironment

class ThresholdLayer:
    def __init__(self, t=3, n=5):
        self.t, self.n = t, n
    def transmit(self, ciphertext, loss_rate):
        t_start = time.perf_counter()
        shares = split_secret(ciphertext, self.t, self.n)
        net = NetworkEnvironment(loss_rate)
        node_ids = net.nodes
        mapped_shares = {node_ids[i]: shares[i+1] for i in range(self.n)}
        received_nodes = net.simulate_delivery(mapped_shares)

        if len(received_nodes) >= self.t:
            recovered_shares = {node_ids.index(nid)+1: data for nid, data in received_nodes.items()}
            recovered_ct = combine_shares(recovered_shares)
            success = True
        else:
            recovered_ct, success = b"", False
        time.sleep(0.02)
        t_end = time.perf_counter()
        return recovered_ct, (t_end - t_start), success