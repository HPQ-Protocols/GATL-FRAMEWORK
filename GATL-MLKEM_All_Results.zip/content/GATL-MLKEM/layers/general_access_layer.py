import time
import random
from shamir.finite_field import gf_add, gf_mul, gf_solve
from network.multipath import NetworkEnvironment

LSSS_MATRIX = [
    [0, 1, 0, 0, 0],
    [1, 1, 0, 0, 0],
    [0, 0, 1, 0, 0],
    [1, 0, 1, 0, 0],
    [0, 0, 0, 1, 0],
    [0, 0, 0, 0, 1],
    [1, 0, 0, 1, 1],
    [0, 0, 0, 1, 0],
    [0, 0, 0, 0, 1],
    [1, 0, 0, 1, 1]
]
LSSS_MAP = ["S1", "G1", "S2", "G1", "S1", "S2", "E1", "D1", "G1", "E1"]

class GeneralAccessTransmissionLayer:
    def transmit(self, ciphertext, loss_rate):
        t_start = time.perf_counter()
        net = NetworkEnvironment(loss_rate)

        node_row_mappings = {nid: [] for nid in set(LSSS_MAP)}
        for r_idx, nid in enumerate(LSSS_MAP): node_row_mappings[nid].append(r_idx)

        outbound_data = {nid: bytearray() for nid in set(LSSS_MAP)}
        for byte in ciphertext:
            v = [byte] + [random.randint(0, 255) for _ in range(4)]
            for nid in outbound_data:
                for r_idx in node_row_mappings[nid]:
                    row = LSSS_MATRIX[r_idx]
                    val = 0
                    for j in range(5): val = gf_add(val, gf_mul(row[j], v[j]))
                    outbound_data[nid].append(val)

        received_nodes = net.simulate_delivery({nid: bytes(outbound_data[nid]) for nid in outbound_data})

        available_row_indices = []
        for nid in received_nodes: available_row_indices.extend(node_row_mappings[nid])
        available_matrix_rows = [LSSS_MATRIX[idx] for idx in available_row_indices]

        coefs = gf_solve(available_matrix_rows, [1, 0, 0, 0, 0])

        if coefs is not None:
            recovered_ct = bytearray()
            for b_idx in range(len(ciphertext)):
                res_byte = 0
                c_count = 0
                for nid in received_nodes:
                    for r_idx in node_row_mappings[nid]:
                        local_idx = node_row_mappings[nid].index(r_idx)
                        row_byte = outbound_data[nid][b_idx * len(node_row_mappings[nid]) + local_idx]
                        res_byte = gf_add(res_byte, gf_mul(coefs[c_count], row_byte))
                        c_count += 1
                recovered_ct.append(res_byte)
            success = True
            recovered_ct = bytes(recovered_ct)
        else:
            recovered_ct, success = b"", False

        time.sleep(0.008)
        t_end = time.perf_counter()
        return recovered_ct, (t_end - t_start), success