import time
import random
class NativeLayer:
    def transmit(self, ciphertext, loss_rate):
        t_start = time.perf_counter()
        success = random.random() >= loss_rate
        time.sleep(0.0005)
        t_end = time.perf_counter()
        return ciphertext if success else b"", (t_end - t_start), success