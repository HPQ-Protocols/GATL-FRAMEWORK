import csv
from layers.native_layer import NativeLayer
from layers.threshold_layer import ThresholdLayer
from layers.general_access_layer import GeneralAccessTransmissionLayer

def main():
    print("--- Chạy Thử Nghiệm Mô Phỏng Nghiêm Túc GATL-MLKEM (Baseline cố định Loss=20%) ---")
    ct = b"A"*1088

    native = NativeLayer()
    thresh = ThresholdLayer()
    gatl = GeneralAccessTransmissionLayer()

    n_lat, t_lat, g_lat = 0, 0, 0
    n_ok, t_ok, g_ok = 0, 0, 0

    for _ in range(100):
        _, t, s = native.transmit(ct, 0.20)
        n_lat += t; n_ok += 1 if s else 0

        _, t, s = thresh.transmit(ct, 0.20)
        t_lat += t; t_ok += 1 if s else 0

        _, t, s = gatl.transmit(ct, 0.20)
        g_lat += t; g_ok += 1 if s else 0

    with open("output/csv/benchmark_results.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Layer Type", "Latency (s)", "Success Rate (%)"])
        writer.writerow(["Native Link", n_lat/100, (n_ok/100)*100])
        writer.writerow(["Threshold Sharing", t_lat/100, (t_ok/100)*100])
        writer.writerow(["GATL Matroid-Based", g_lat/100, (g_ok/100)*100])

    print("Xuất kết quả đo lường thành công ra file benchmark_results.csv")

if __name__ == '__main__': main()