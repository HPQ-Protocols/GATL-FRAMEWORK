import random
from shamir.finite_field import gf_add, gf_mul

def split_secret(secret_bytes, t, n):
    shares = {i: bytearray() for i in range(1, n + 1)}
    for byte in secret_bytes:
        coeffs = [byte] + [random.randint(0, 255) for _ in range(t - 1)]
        for x in range(1, n + 1):
            val = 0
            for c in reversed(coeffs): val = gf_add(gf_mul(val, x), c)
            shares[x].append(val)
    return {i: bytes(shares[i]) for i in range(1, n + 1)}