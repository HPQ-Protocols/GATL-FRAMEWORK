from shamir.finite_field import gf_add, gf_mul, gf_inv

def combine_shares(shares_dict):
    if not shares_dict: return b""
    first_share = list(shares_dict.values())[0]
    secret = bytearray()
    for idx in range(len(first_share)):
        points = [(x, shares_dict[x][idx]) for x in shares_dict]
        byte_val = 0
        for i in range(len(points)):
            xi, yi = points[i]
            num, den = 1, 1
            for j in range(len(points)):
                if i != j:
                    xj, _ = points[j]
                    num = gf_mul(num, xj)
                    den = gf_mul(den, gf_add(xi, xj))
            lagrange = gf_mul(yi, gf_mul(num, gf_inv(den)))
            byte_val = gf_add(byte_val, lagrange)
        secret.append(byte_val)
    return bytes(secret)