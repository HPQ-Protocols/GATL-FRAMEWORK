def gf_add(a, b): return a ^ b

def gf_mul(a, b):
    p = 0
    for _ in range(8):
        if b & 1: p ^= a
        hi = a & 0x80
        a <<= 1
        if hi: a ^= 0x11b
        b >>= 1
    return p & 0xFF

def gf_inv(a):
    if a == 0: return 0
    p, res, power = a, 1, 254
    while power > 0:
        if power & 1: res = gf_mul(res, p)
        p = gf_mul(p, p)
        power >>= 1
    return res

def gf_solve(matrix_rows, target):
    n = len(matrix_rows)
    if n == 0: return None
    d = len(matrix_rows[0])
    aug = []
    for i in range(n):
        aug.append(list(matrix_rows[i]) + [0]*n)
        aug[i][d + i] = 1
    r = 0
    for c in range(d):
        pivot = -1
        for i in range(r, n):
            if aug[i][c] != 0:
                pivot = i
                break
        if pivot == -1: continue
        aug[r], aug[pivot] = aug[pivot], aug[r]
        inv = gf_inv(aug[r][c])
        for j in range(c, len(aug[r])): aug[r][j] = gf_mul(aug[r][j], inv)
        for i in range(n):
            if i != r and aug[i][c] != 0:
                factor = aug[i][c]
                for j in range(c, len(aug[i])): aug[i][j] = gf_add(aug[i][j], gf_mul(factor, aug[r][j]))
        r += 1
    curr_target = list(target)
    coefs = [0] * n
    for i in range(r):
        lead_c = -1
        for j in range(d):
            if aug[i][j] != 0:
                lead_c = j
                break
        if lead_c != -1 and curr_target[lead_c] != 0:
            factor = curr_target[lead_c]
            for j in range(d): curr_target[j] = gf_add(curr_target[j], gf_mul(factor, aug[i][j]))
            for j in range(n): coefs[j] = gf_add(coefs[j], gf_mul(factor, aug[i][d + j]))
    if any(v != 0 for v in curr_target): return None
    return coefs