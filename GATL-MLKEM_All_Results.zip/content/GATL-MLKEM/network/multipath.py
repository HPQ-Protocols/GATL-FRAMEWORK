import random
class NetworkEnvironment:
    def __init__(self, loss_rate=0.2):
        self.loss_rate = loss_rate
        self.nodes = ['S1', 'S2', 'G1', 'D1', 'E1']
    def simulate_delivery(self, outbound_shares):
        received = {}
        for node_id, data in outbound_shares.items():
            if random.random() >= self.loss_rate:
                received[node_id] = data
        return received